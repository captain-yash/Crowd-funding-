import React from "react";

const AdminTransactions = () => {
  return (
    <div className="container py-5">
      <h2 className="text-center fw-bold">View Transactions</h2>
      <p className="text-center text-muted">Track donation transactions and manage payouts.</p>
      {/* List of transactions with details */}
    </div>
  );
};

export default AdminTransactions;
