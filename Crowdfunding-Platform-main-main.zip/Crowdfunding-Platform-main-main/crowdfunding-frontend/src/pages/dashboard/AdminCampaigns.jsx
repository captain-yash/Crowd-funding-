import React from "react";

const AdminCampaigns = () => {
  return (
    <div className="container py-5">
      <h2 className="text-center fw-bold">Manage Campaigns</h2>
      <p className="text-center text-muted">Approve, reject, or remove campaigns.</p>
      {/* List of campaigns with action buttons */}
    </div>
  );
};

export default AdminCampaigns;
