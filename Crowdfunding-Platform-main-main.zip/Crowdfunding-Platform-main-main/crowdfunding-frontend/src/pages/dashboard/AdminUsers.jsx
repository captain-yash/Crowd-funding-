import React from "react";

const AdminUsers = () => {
  return (
    <div className="container py-5">
      <h2 className="text-center fw-bold">Manage Users</h2>
      <p className="text-center text-muted">Suspend or remove users from the platform.</p>
      {/* List of users with action buttons */}
    </div>
  );
};

export default AdminUsers;
